package com.priya.ai;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_SPEECH = 101;
    private static final int REQ_AUDIO = 102;
    private TextView chat;
    private EditText input;
    private ScrollView scroll;
    private TextToSpeech tts;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        chat = findViewById(R.id.chat);
        input = findViewById(R.id.input);
        scroll = findViewById(R.id.scroll);
        Button send = findViewById(R.id.send);
        Button mic = findViewById(R.id.mic);
        prefs = getSharedPreferences("priya_memory", MODE_PRIVATE);

        String saved = prefs.getString("chat", "");
        if (!saved.isEmpty()) chat.setText(saved);
        else append("Priya", "हाय ❤️ मैं Priya हूँ। मुझसे बात करो।");

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("hi", "IN"));
        });

        send.setOnClickListener(v -> sendMessage());
        input.setOnEditorActionListener((v, actionId, event) -> { sendMessage(); return true; });
        mic.setOnClickListener(v -> startSpeech());
    }

    private void sendMessage() {
        String text = input.getText().toString().trim();
        if (text.isEmpty()) return;
        append("आप", text);
        input.setText("");

        String lower = text.toLowerCase(Locale.ROOT);
        String reply;
        if (lower.contains("नमस्ते") || lower.contains("हाय") || lower.contains("hello") || lower.equals("hi")) {
            reply = "हाय ❤️ कैसे हो? आज क्या कर रहे हो?";
        } else if (lower.contains("नाम")) {
            reply = "मेरा नाम Priya है ❤️";
        } else if (lower.contains("कहाँ गए") || lower.contains("कहां गए")) {
            reply = "अच्छा, कहाँ गए थे? किसके साथ गए थे? 😄";
        } else if (lower.contains("प्यार") || lower.contains("love you")) {
            reply = "अच्छा जी ❤️ पहले बताओ, आज दिन कैसा रहा?";
        } else if (lower.contains("गुस्सा") || lower.contains("नाराज़") || lower.contains("नाराज")) {
            reply = "थोड़ा गुस्सा आ सकता है 😄 लेकिन पहले पूरी बात बताओ।";
        } else if (lower.contains("धन्यवाद") || lower.contains("thanks")) {
            reply = "कोई बात नहीं ❤️";
        } else {
            reply = "हम्म... समझ गई ❤️ थोड़ा और बताओ।";
        }
        append("Priya", reply);
        if (tts != null) tts.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "priya");
    }

    private void append(String who, String text) {
        String old = chat.getText().toString();
        String all = old.isEmpty() ? who + ": " + text : old + "\n\n" + who + ": " + text;
        chat.setText(all);
        prefs.edit().putString("chat", all).apply();
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    private void startSpeech() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "बोलिए...");
        try { startActivityForResult(i, REQ_SPEECH); } catch (Exception ignored) { }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) {
                input.setText(results.get(0));
                input.setSelection(input.length());
            }
        }
    }

    @Override
    protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
