# Priya AI Free V1
Hindi text chat, Hindi speech input, text-to-speech, local conversation memory, and basic personality rules.
This is Android source code, not a prebuilt APK. Build with Android Studio/compatible Android build environment.
